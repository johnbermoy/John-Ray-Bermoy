######## INSTALLATION FOR MY WEB APPLICATION ##############


STEP 1: YOU MUST IMPORT THE bermoy.sql in localhost.
STEP 2: AFTER YOU UPLOADED THE FILE. THE DATABASE NAME IS "bermoy" DATABASE TABLE IS "bermoy_tbl".
STEP 3: NOW VISIT THIS LINK: http://localhost/Bermoy/Cont_B/main