<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
	<title><?php 

		if ($about) {
			foreach ($about as $data) {
			    echo $data->fname." ".$data->lname;
			}
		}
	?></title>
	<link rel="stylesheet" href="<?php echo base_url('assets/css/perso.css') ?>">
</head>
<body>


<header>
	<div id="head">
		<ul>
			<li><span onclick="back();">Back</span></li>
			
		</ul>
	</div>
</header>


<!-- img -->

	<div class="flex_img">
		
		<div class="intro_text">
			<center><h3 style="padding: 10px 0px; font-size: 32px;font-family: 'Poppins', sans-serif;">Personal Information</h3></center>
			<p>
				<?php 

				if ($about) {
					foreach ($about as $data) {
					    echo $data->about_me;
					}
				}
			?>
			</p>
		</div>
	</div>


<!-- end of img -->




	<script type="text/javascript">
		
		function back() {
			// body...
			window.location.href="<?php echo base_url('Cont_B/main_p') ?>"; 
		}
		function personal(){
			window.location.href="personal_info.html"; 
		}

	</script>

	
</body>
</html>


