<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title><?php 

		if ($person) {
			foreach ($person as $data) {
			    echo $data->fname." ".$data->lname;
			}
		}
	?></title>
	<link rel="stylesheet" href="<?php echo base_url('assets/css/perso.css') ?>">
</head>
<body>


<header>
	<div id="head">
		<ul>
			<li><span onclick="back();">Back</span></li>
			<!-- <li><span>John Ray</span></li> -->
		</ul>
	</div>
</header>

<div class="box">
		<div class="content">
			<div class="flex">
				<button class="box1" onclick="personal()">Personal Information</button>
				<!-- <button class="box2" onclick="skills();">Skills</button> -->
				<button class="box3" onclick="about()">About me</button>
			</div>
		</div>
	</div>


	<script type="text/javascript">
		
		function back() {
			// body...
			window.location.href="<?php echo base_url('Cont_B/main') ?>"; 
		}
		function personal(){
			window.location.href="<?php echo base_url('Cont_B/personal')?>"; 
		}

		function about(){
			window.location.href="<?php echo base_url('Cont_B/about_me')?>"; 
		}
	</script>

	
</body>
</html>


