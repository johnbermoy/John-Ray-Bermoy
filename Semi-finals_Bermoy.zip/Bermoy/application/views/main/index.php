<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<link href="https://fonts.googleapis.com/css2?family=Nerko+One&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
	<title><?php 

		if ($tbl_d) {
			foreach ($tbl_d as $data) {
			    echo $data->fname." ".$data->lname;
			}
		}
	?></title>
	<link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="<?php echo base_url('assets/css/style.css') ?>">
	<link href="https://fonts.googleapis.com/css2?family=Nerko+One&display=swap" rel="stylesheet">
</head>
<body>

<!-- header -->
	<header>
		<div class="head">
			<a href="<?php echo base_url('Cont_B/main') ?>"><span style="font-size: 30px; color: black;">Web application</span></a>
		</div>
		<div class="list">
			<ul>
				<li><span onclick="person();">Personal</span></li>
				<li><span>About Me</span></li>
			</ul>
		</div>
	</header>
	<!-- end of header -->


	<!-- content -->

	<div class="flex">
		<div class="text">
			<p>Johnny The Brave</p>
			<!-- <button>ctrl + alt + del</button> -->
			<div class="line">
			</div>
			<div class="txt_btm">
				<p>fell the fear and do it anyway.</p>
			</div>
		</div>
			<div class="img">
				<ul>
					<li><img id="brave" src="<?php echo base_url();?>assets/images/brave.png" alt="Brave" width="160" height="160"></li>
					<li><img id="male" src="<?php echo base_url();?>assets/images/male.png" alt="Brave" width="90" height="90"></li>
				</ul>
			</div>
	</div>


	
	

	<!-- end of content -->

	<script type="text/javascript">
		
		function person(){
			window.location.href="<?php echo base_url('Cont_B/main_p') ?>";
		}

	</script>
	
</body>
</html>


