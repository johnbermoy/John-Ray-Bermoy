<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
	<title><?php 

		if ($p) {
			foreach ($p as $data) {
			    echo $data->fname." ".$data->lname;
			}
		}
	?></title>
	<link rel="stylesheet" href="<?php echo base_url('assets/css/perso.css') ?>">
</head>
<body>


<header>
	<div id="head">
		<ul>
			<li><span onclick="back();">Back</span></li>
			
		</ul>
	</div>
</header>


<!-- img -->

	<div class="flex_img">
		<div class="img_size">
			<img src="<?php echo base_url('assets/images/bermoy.jpg') ?>" alt="Image" width="300" height="300">
			<!-- <p>daw</p> -->
		</div>
		<div class="intro">
			<ul>
				<li><span>Name: <?php 
					if ($p) {
						foreach ($p as $data) {
						    echo $data->fname." ".$data->lname;
						}
					}
				?></span></li>
				<li><span>Nationality: <?php 
					if ($p) {
						foreach ($p as $data) {
						    echo $data->nationality;
						}
					}
				?></span></li>
				<li><span>Status: <?php 
					if ($p) {
						foreach ($p as $data) {
						    echo $data->stat;
						}
					}
				?></span></li>
				<li><span>Language spoken: <?php 
					if ($p) {
						foreach ($p as $data) {
						    echo $data->language_spoken;
						}
					}
				?></span></li>
				<li><span>Email: <?php 
					if ($p) {
						foreach ($p as $data) {
						    echo $data->email;
						}
					}
				?></span></li>
				<li><span>Skills: <?php 
					if ($p) {
						foreach ($p as $data) {
						    echo $data->skills;
						}
					}
				?></span></li>
				<li><span>Motto in life: <?php 
					if ($p) {
						foreach ($p as $data) {
						    echo $data->motto;
						}
					}
				?></span></li>
			</ul>
		</div>
	</div>


<!-- end of img -->




	<script type="text/javascript">
		
		function back() {
			// body...
			window.location.href="<?php echo base_url('Cont_B/main_p') ?>"; 
		}
		function pal(){
			window.location.href="<?php echo base_url('Cont_B/main') ?>"; 
		}

	</script>

	
</body>
</html>


