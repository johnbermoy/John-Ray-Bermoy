<?php  

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * summary
 */
class B_Data extends CI_Model
{
    /**
     * summary
     */
    public function get_data()
    {
        $table = $this->db->table_exists('bermoy_tbl');
	    	if ($table) {
	    		$que = $this->db->get('bermoy_tbl');
	    		if ($que->num_rows() > 0) {
	    			return $que->result();
	    		}
	    		else{
	    			return false;
	    		}
	    	}
	    	else {
	    		return false;
	    	}
    }
}

?>