<?php  

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * summary
 */
class Cont_B extends CI_Controller
{
    /**
     * summary
     */
    function main(){

    	$data['tbl_d'] = $this->data_b->get_data();
    	$this->load->view('main/index',$data);
    }

    function __construct()
    {
    	parent:: __construct();
    	$this->load->model('b_data','data_b');
    }

    function main_p(){
		$data['person'] = $this->data_b->get_data();
    	$this->load->view('main/main',$data);
    }
    function about_me(){
		$data['about'] = $this->data_b->get_data();
    	$this->load->view('main/about',$data);
    }
    function skills(){
		$data['skills'] = $this->data_b->get_data();
    	$this->load->view('main/skills',$data);
    }
    function personal(){
        $data['p'] = $this->data_b->get_data();
        $this->load->view('main/personal',$data);
    }
}


?>