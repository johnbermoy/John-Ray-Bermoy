-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 03, 2020 at 02:01 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bermoy`
--

-- --------------------------------------------------------

--
-- Table structure for table `bermoy_tbl`
--

CREATE TABLE `bermoy_tbl` (
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `nationality` varchar(50) NOT NULL,
  `stat` varchar(50) NOT NULL,
  `language_spoken` varchar(255) NOT NULL,
  `email` varchar(50) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `skills` text NOT NULL,
  `motto` text NOT NULL,
  `about_me` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bermoy_tbl`
--

INSERT INTO `bermoy_tbl` (`fname`, `lname`, `nationality`, `stat`, `language_spoken`, `email`, `contact`, `skills`, `motto`, `about_me`) VALUES
('John Ray', 'Bermoy', 'Filipino', 'Single', 'Cebuana English and Tagalog', 'bermoyjohnray@gmail.com', '09308064910', 'MS Skills,Customer Service ,Results Oriented', 'Pray More Worry Less', 'I am John Ray Bermoy, 20 years old and currently living at Barangay 17, Fort Poyohon Butuan City. I finished my Senior High School in Agay National High School, RTR, Agusan del Norte. When I took in college, I enrolled and currently taking a Bachelor of Science in Information Technology (BSIT). I choose BSIT as my degree course because I know myself that I am capable with this course that I take. I have my background and having a certificate in Microsoft Office which I was successfully completed the course of Braintrust Computer Learning at Saint Joseph Institute of Technology. And as of now, I became a proud Student  Assistant at Father Saturnino Urios University and currently assigned in Nursing Deans Office.');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
